export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyCwWUPtAAXvw7gaB8YBaaLyNF0U4IucWUc",
    authDomain: "cleanit-e7639.firebaseapp.com",
    projectId: "cleanit-e7639",
    storageBucket: "cleanit-e7639.firebasestorage.app",
    messagingSenderId: "569982436503",
    appId: "1:569982436503:web:deea8acb1fe35edbdd95d2",
    measurementId: "G-R785XQB267"
  }
};
