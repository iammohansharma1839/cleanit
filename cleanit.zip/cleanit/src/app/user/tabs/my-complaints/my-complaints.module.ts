import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MyComplaintsPageRoutingModule } from './my-complaints-routing.module';

import { MyComplaintsPage } from './my-complaints.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MyComplaintsPageRoutingModule
  ],
  declarations: [MyComplaintsPage]
})
export class MyComplaintsPageModule {}
