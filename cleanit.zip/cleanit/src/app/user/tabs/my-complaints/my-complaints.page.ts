import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-complaints',
  templateUrl: './my-complaints.page.html',
  styleUrls: ['./my-complaints.page.scss'],
})
export class MyComplaintsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
