import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MyComplaintsPage } from './my-complaints.page';

describe('MyComplaintsPage', () => {
  let component: MyComplaintsPage;
  let fixture: ComponentFixture<MyComplaintsPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(MyComplaintsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
