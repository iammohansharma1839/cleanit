import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-complaint-form',
  templateUrl: './complaint-form.page.html',
  styleUrls: ['./complaint-form.page.scss'],
})
export class ComplaintFormPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
