import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ComplaintFormPage } from './complaint-form.page';

describe('ComplaintFormPage', () => {
  let component: ComplaintFormPage;
  let fixture: ComponentFixture<ComplaintFormPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplaintFormPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
