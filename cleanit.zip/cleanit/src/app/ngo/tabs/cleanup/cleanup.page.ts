import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cleanup',
  templateUrl: './cleanup.page.html',
  styleUrls: ['./cleanup.page.scss'],
})
export class CleanupPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
