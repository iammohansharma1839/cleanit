import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CleanupPageRoutingModule } from './cleanup-routing.module';

import { CleanupPage } from './cleanup.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CleanupPageRoutingModule
  ],
  declarations: [CleanupPage]
})
export class CleanupPageModule {}
