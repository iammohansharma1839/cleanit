import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthService {
  constructor(
    private afAuth: AngularFireAuth,
    private firestore: AngularFirestore,
    private router: Router
  ) {}

  // Login with email/password
  async login(email: string, password: string): Promise<any> {
    try {
      const result = await this.afAuth.signInWithEmailAndPassword(email, password);
      this.router.navigate([this.getRoleRoute(result.user)]);
      return result;
    } catch (error) {
      throw error;
    }
  }

  private getRoleRoute(user: any) {
    // Implement role detection logic from Firestore
  }

  // Registration
  async register(userData: User, role: string): Promise<any> {
    try {
      const result = await this.afAuth.createUserWithEmailAndPassword(
        userData.email, 
        userData.password
      );
      
      await this.firestore.collection(role).doc(result.user?.uid).set({
        name: userData.name,
        email: userData.email,
        createdAt: new Date(),
        role: role
      });
      
      return result;
    } catch (error) {
      throw error;
    }
  }

  // Logout
  async logout(): Promise<void> {
    await this.afAuth.signOut();
    this.router.navigate(['/login']);
  }

  // Get current user
  getCurrentUser(): Observable<any> {
    return this.afAuth.authState;
  }


  async getUserRole(uid: string): Promise<string> {
    const userDoc = await this.firestore.collection('users').doc(uid).get().toPromise();
    if (userDoc.exists) return 'user';
    
    const ngoDoc = await this.firestore.collection('ngos').doc(uid).get().toPromise();
    if (ngoDoc.exists) return 'ngo';
    
    const adminDoc = await this.firestore.collection('admins').doc(uid).get().toPromise();
    if (adminDoc.exists) return 'admin';
    
    return 'unknown';
  }
}