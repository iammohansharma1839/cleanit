import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { AngularFireStorage } from '@angular/fire/compat/storage';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ComplaintService {
  constructor(
    private firestore: AngularFirestore,
    private storage: AngularFireStorage
  ) {}

  createComplaint(complaint: any): Promise<any> {
    return this.firestore.collection('complaints').add({
      ...complaint,
      createdAt: new Date(),
      status: 'pending'
    });
  }

  getComplaintsByUser(userId: string): Observable<any[]> {
    return this.firestore.collection('complaints', ref => 
      ref.where('userId', '==', userId).orderBy('createdAt', 'desc')
    ).valueChanges({ idField: 'id' });
  }

  getAllComplaints(): Observable<any[]> {
    return this.firestore.collection('complaints').valueChanges({ idField: 'id' });
  }

  updateComplaintStatus(id: string, status: string): Promise<void> {
    return this.firestore.collection('complaints').doc(id).update({ status });
  }

  async uploadImage(imageBlob: Blob, userId: string): Promise<string> {
    const filePath = `complaints/${userId}/${Date.now()}`;
    const fileRef = this.storage.ref(filePath);
    const task = await fileRef.put(imageBlob);
    return task.ref.getDownloadURL();
  }
}