import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertController, LoadingController } from '@ionic/angular';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  credentials: FormGroup;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private alertController: AlertController,
    private router: Router,
    private loadingController: LoadingController
  ) { }

  ngOnInit() {
    this.credentials = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  async login() {
    const loading = await this.loadingController.create();
    await loading.present();

    this.authService.login(this.credentials.value.email, this.credentials.value.password).subscribe(
      async (res) => {
        await loading.dismiss();
        
        // Get user role from Firestore
        this.authService.getCurrentUser().subscribe(async (user) => {
          const role = await this.authService.getUserRole(user.uid);
          
          if(role === 'admin') {
            this.router.navigateByUrl('/admin', { replaceUrl: true });
          } else if(role === 'ngo') {
            this.router.navigateByUrl('/ngo', { replaceUrl: true });
          } else {
            this.router.navigateByUrl('/user', { replaceUrl: true });
          }
        });
      },
      async (err) => {
        await loading.dismiss();
        const alert = await this.alertController.create({
          header: 'Login failed',
          message: err.message,
          buttons: ['OK'],
        });
        await alert.present();
      }
    );
  }

  get email() {
    return this.credentials.get('email');
  }

  get password() {
    return this.credentials.get('password');
  }
}